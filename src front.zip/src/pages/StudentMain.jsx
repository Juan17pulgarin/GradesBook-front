import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api/api";
import "../styles/StudentMain.css";

export default function StudentMain() {
    const navigate = useNavigate();
    const user = JSON.parse(localStorage.getItem("user") || "{}");
    const primerNombre = user.nombreCompleto?.split(" ")[0] || "Estudiante";

    const [periods, setPeriods] = useState([]);

    useEffect(() => {
        // Intentar cargar periodos — silencioso si da 403
        api.get("/periods")
            .then((res) => setPeriods(res.data))
            .catch(() => {}); // silencioso, no rompe la vista
    }, []);

    const handleLogout = () => {
        localStorage.removeItem("token");
        localStorage.removeItem("user");
        navigate("/");
    };

    const materias = [
        { nombre: "Matemáticas", ultimoTema: "Fracciones y Decimales", nota: 9.5, badge: "EXCELENTE", badgeColor: "blue", progreso: 95, barColor: "#3b82f6" },
        { nombre: "Ciencias Naturales", ultimoTema: "El Ciclo del Agua", nota: 8.8, badge: "MUY BIEN", badgeColor: "green", progreso: 88, barColor: "#84cc16" },
        { nombre: "Artes Plásticas", ultimoTema: "Teoría del Color", nota: 10.0, badge: "PERFECTO", badgeColor: "yellow", progreso: 100, barColor: "#f59e0b" },
    ];

    const boletin = [
        { asignatura: "Lengua y Literatura", nota: 9.2, comentario: "Excelente comprensión lectora." },
        { asignatura: "Historia y Geografía", nota: 8.5, comentario: "Participación activa en clase." },
        { asignatura: "Educación Física", nota: 9.8, comentario: "Gran líder en actividades grupales." },
        { asignatura: "Idioma Extranjero", nota: 9.0, comentario: "Muy buen progreso en fonética." },
    ];

    const promedioGeneral = (materias.reduce((acc, m) => acc + m.nota, 0) / materias.length).toFixed(1);

    return (
        <div className="sm-page">

            {/* TOPBAR */}
            <div className="sm-topbar">
                <div className="sm-logo">GradesBook</div>
                <div className="sm-topbar-right">
                    <div className="sm-search">
                        <span className="sm-search-icon">🔍</span>
                        <input placeholder="Buscar mi progreso..." />
                    </div>
                    <span className="sm-icon">🔔</span>
                    <span className="sm-icon">⚙️</span>
                    <div className="sm-avatar">{primerNombre[0]}</div>
                </div>
            </div>

            <div className="sm-content">

                {/* HERO */}
                <div className="sm-hero">
                    <div className="sm-hero-left">
                        <h1>¡Hola, {primerNombre}! 🚀</h1>
                        <p>Estás teniendo un trimestre increíble. ¡Sigue brillando como una estrella!</p>
                        <button className="sm-hero-btn">Ver Boletín Completo</button>
                    </div>
                    <div className="sm-hero-right">
                        <div className="sm-promedio-circle">
                            <svg viewBox="0 0 100 100" className="sm-circle-svg">
                                <circle cx="50" cy="50" r="42" fill="none" stroke="rgba(255,255,255,0.2)" strokeWidth="8" />
                                <circle cx="50" cy="50" r="42" fill="none" stroke="#84cc16" strokeWidth="8"
                                    strokeDasharray="263.9" strokeDashoffset="26"
                                    strokeLinecap="round" transform="rotate(-90 50 50)" />
                            </svg>
                            <div className="sm-circle-text">
                                <span className="sm-circle-value">{promedioGeneral}</span>
                                <span className="sm-circle-label">PROMEDIO GENERAL</span>
                            </div>
                        </div>
                    </div>
                </div>

                {/* PERIODOS — solo si el back los devuelve */}
                {periods.length > 0 && (
                    <div className="sm-periodos-section">
                        <h2>Periodos Académicos</h2>
                        <div className="sm-periodos">
                            {periods.map((p) => (
                                <div className="sm-periodo-card" key={p.id}>
                                    <span className="sm-periodo-icon">📅</span>
                                    <div>
                                        <h4>{p.nombre}</h4>
                                        <p>
                                            {new Date(p.fecha_inicio).toLocaleDateString("es-CO")} →{" "}
                                            {new Date(p.fecha_fin).toLocaleDateString("es-CO")}
                                        </p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                )}

                {/* CALIFICACIONES */}
                <div className="sm-section">
                    <div className="sm-section-header">
                        <div>
                            <h2>Mis Calificaciones</h2>
                            <p>Seguimiento de tus metas este trimestre</p>
                        </div>
                        <span className="sm-link">Ver histórico ↗</span>
                    </div>

                    <div className="sm-materias">
                        {materias.map((m, i) => (
                            <div className="sm-materia-card" key={i}>
                                <div className="sm-materia-top">
                                    <div className="sm-materia-icon">📘</div>
                                    <div className="sm-materia-nota-box">
                                        <span className="sm-materia-nota">{m.nota}</span>
                                        <span className={`sm-badge sm-badge-${m.badgeColor}`}>{m.badge}</span>
                                    </div>
                                </div>
                                <h3 className="sm-materia-nombre">{m.nombre}</h3>
                                <p className="sm-materia-tema">Último tema: {m.ultimoTema}</p>
                                <div className="sm-progress-label">PROGRESO DE METAS</div>
                                <div className="sm-progress-bar">
                                    <div className="sm-progress-fill"
                                        style={{ width: `${m.progreso}%`, background: m.barColor }} />
                                </div>
                                <span className="sm-progress-pct">{m.progreso}%</span>
                            </div>
                        ))}
                    </div>
                </div>

                {/* BOLETÍN + CONSEJO */}
                <div className="sm-bottom">

                    <div className="sm-boletin">
                        <div className="sm-boletin-header">
                            <div>
                                <h2>Boletín de Calificaciones</h2>
                                <p>Primer Trimestre • 2024</p>
                            </div>
                            <div className="sm-boletin-actions">
                                <button title="Descargar">⬇</button>
                                <button title="Imprimir">🖨</button>
                            </div>
                        </div>
                        <div className="sm-boletin-table">
                            <div className="sm-boletin-thead">
                                <span>ASIGNATURA</span>
                                <span>NOTA FINAL</span>
                                <span>COMENTARIO</span>
                            </div>
                            {boletin.map((b, i) => (
                                <div className="sm-boletin-row" key={i}>
                                    <span>{b.asignatura}</span>
                                    <span className="sm-boletin-nota">{b.nota}</span>
                                    <span className="sm-boletin-comentario">{b.comentario}</span>
                                </div>
                            ))}
                        </div>
                    </div>

                    <div className="sm-consejo">
                        <div className="sm-consejo-header">CONSEJO DE PROFE ANA</div>
                        <p className="sm-consejo-text">
                            "{primerNombre}, tu esfuerzo en las fracciones está dando frutos. Sigue practicando
                            10 minutos al día para ser imparable."
                        </p>
                        <button className="sm-logout" onClick={handleLogout}>
                            Cerrar sesión
                        </button>
                    </div>

                </div>

            </div>
        </div>
    );
}